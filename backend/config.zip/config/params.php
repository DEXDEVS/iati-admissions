<?php
return [
    'adminEmail' => 'admin@example.com',
];
